# Express-U
App made for artists share their performance and to people see close by performances and search/follow artists.

Clinton de Sá,
Matheus Vasconcelos,
Renan Trévia,
Yuri Frota.
